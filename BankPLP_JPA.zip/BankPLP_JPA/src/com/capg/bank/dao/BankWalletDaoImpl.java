package com.capg.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capg.bank.exception.InsufficientBalanceException;
import com.capg.bank.model.Account;

public class BankWalletDaoImpl implements BankWalletDao 
{
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("PLPWithJPA");
    EntityManager em=emf.createEntityManager();
    TypedQuery<Account> tq;
    long accBal;
	
	@Override
	public boolean saveAccount(Account a) 
	{
		em.getTransaction().begin();
		em.persist(a);
		em.getTransaction().commit();
		return true;	
	}

	@Override
	public long viewBalance(String accountNo, String pin) 
	{
	   em.getTransaction().begin();
	   tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.pin= :p", Account.class);
       tq.setParameter("acNo", accountNo);
       tq.setParameter("p", pin);
	   Account a= tq.getSingleResult();
	   em.getTransaction().commit();
	   if(a!=null)
		   return a.getAccountBalance();
		return -1;
	}

	@Override
	public long depositCash(String accountNo,long amount) 
	{
		em.getTransaction().begin();
	    tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo", Account.class);
        tq.setParameter("acNo",accountNo);
     
        accBal= tq.getSingleResult().getAccountBalance();
        
        tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo", Account.class);
        tq.setParameter("amt", accBal+amount);
        tq.setParameter("acNo", accountNo);
    
        int i=tq.executeUpdate();
       
       em.getTransaction().commit();
       if(i>0)
		return accBal+amount;
	   return -1;
	}

	@Override
	public long withdrawCash(String accountNo, String pin,long amount) throws InsufficientBalanceException 
	{
		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.pin= :p", Account.class);
        tq.setParameter("acNo", accountNo);
        tq.setParameter("p", pin);
     
        accBal = tq.getSingleResult().getAccountBalance();
        if(accBal>=amount)
        {
        em.getTransaction().begin();
        tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo", Account.class);
        tq.setParameter("amt", accBal-amount);
        tq.setParameter("acNo", accountNo);
    
        int i=tq.executeUpdate();
      
        em.getTransaction().commit();
        if(i>0)
          return accBal-amount;
        else return -1;
        }
        else throw new InsufficientBalanceException("Insufficient Balance");
	}

	@Override
	public boolean transferMoney(String sourceAcNo, String destAcNo, long amount,String pin) throws InsufficientBalanceException {
		
		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.pin= :p", Account.class);
        tq.setParameter("acNo", sourceAcNo);
        tq.setParameter("p", pin);
     
        accBal = tq.getSingleResult().getAccountBalance();
        if(accBal>=amount)
        {
        em.getTransaction().begin();
        tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo", Account.class);
        tq.setParameter("amt", accBal-amount);
        tq.setParameter("acNo", sourceAcNo);
    
        int i=tq.executeUpdate();
      
        em.getTransaction().commit();
        if(i>0)
          return true;
        else return false;
        }
        else throw new InsufficientBalanceException("Insufficient Balance");
	}

}
